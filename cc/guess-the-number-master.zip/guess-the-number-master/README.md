# Guess The Number

This is an application for the purpose of learning Javascript for the Atlanta TIY Crash Course.
---

The following files are included:

* index.html
* main.css
* main.js

However, `main.js` is left empty to be implemented during the crash course.

To see a demo of the finished app, [click here](http://tiy-atlanta.github.io/guess-the-number/).

---

### Setup Instructions

1. Click the `Download ZIP` button to download the project
2. Extract the file contents from the zip
3. Open the `main.js` file in your favorite text editor



